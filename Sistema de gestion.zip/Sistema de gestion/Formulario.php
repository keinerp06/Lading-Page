<?php
class Contacto {
    public $nombre;
    public $email;
    public $mensaje;

    public function __construct($nombre, $email, $mensaje) {
        $this->nombre = htmlspecialchars($nombre);
        $this->email = htmlspecialchars($email);
        $this->mensaje = htmlspecialchars($mensaje);
    }

    public function mostrarMensaje() {
        return "<div class='message-box'>
                    <h2>Datos Enviados:</h2>
                    <p><strong>Nombre:</strong> {$this->nombre}</p>
                    <p><strong>Email:</strong> {$this->email}</p>
                    <p><strong>Mensaje:</strong> " . nl2br($this->mensaje) . "</p>
                    <button onclick=\"location.href='index.html'\" class='btn'>Ir a Inicio</button>

                </div>";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'] ?? '';
    $email = $_POST['email'] ?? '';
    $mensaje = $_POST['mensaje'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "El correo ingresado no es válido.";
        exit;
    }

    $contacto = new Contacto($nombre, $email, $mensaje);
    echo $contacto->mostrarMensaje();
}
?>